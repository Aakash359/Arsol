/** @format */

export default {
 
  lgreen: '#aed581',

  // navigation bar
  headerTintColor: '#ff7100',
  bgColor: '#84D337',

 
  // common
  error: '#f44336',



  red: '#FF0000',
  btn:'#335E61'

};
