export default {
  SuitCRM: {
    noInternet: 'Internet connection unavailable',
    sessionExp: 'Session expire',
    netError: 'Network error',
    servErr: 'Server error',
    serTimErr: 'Server timeout error ',

    //http://invoice.tactionsoft.com/api/LoginUser/DashBoard
    arsolurl: 'http://invoice.tactionsoft.com/api',
  },
};
